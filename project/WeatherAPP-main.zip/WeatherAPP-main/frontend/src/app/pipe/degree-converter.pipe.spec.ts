import { DegreeConverterPipe } from './degree-converter.pipe';

describe('DegreeConverterPipe', () => {
  it('create an instance', () => {
    const pipe = new DegreeConverterPipe();
    expect(pipe).toBeTruthy();
  });
});
