export class Signup{
    constructor(public username:string,public password:string)
    {

    }
}