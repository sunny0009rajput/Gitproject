export class Temperature {

    temp: number | undefined;
    feelsLike: number | undefined;
    tempMin: number | undefined;
    tempMax: number | undefined;
    pressure: number | undefined;
    humidity: number | undefined;
}