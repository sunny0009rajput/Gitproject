export class Coordinate {
    lat: number | undefined;
    lon: number | undefined;
}