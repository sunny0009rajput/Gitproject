export class Weather {

    mainInfo:string | undefined;
    description:string | undefined;
    
 }