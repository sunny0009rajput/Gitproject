package com.trainingapps.watchlist;

import com.trainingapps.watchlist.service.IWatchListService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
class WatchListApplicationTests {
	private IWatchListService service;

	@Test
	void contextLoads() {
	}


	/**
	 * scenerio when weather is present in the city
	 * input: coutnry=India, city=haryana, userName=shivam
	 */
//	@Test
//	public void TestForRemoveFavorite_1()
//	{
//
//
//	}




}
