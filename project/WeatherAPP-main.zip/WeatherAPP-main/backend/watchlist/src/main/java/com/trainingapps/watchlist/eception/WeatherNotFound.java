package com.trainingapps.watchlist.eception;

public class WeatherNotFound extends Exception{
    public WeatherNotFound(String msg)
    {
        super(msg);
    }

}
