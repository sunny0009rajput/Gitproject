package com.trainingapps.userms.exceptions;

public class IncorrectCredentialsException extends Exception{
    public IncorrectCredentialsException(String msg){
        super(msg);
    }
}
