package com.usermanagementfeign.usermanagementfeign.entity;

import lombok.Data;

@Data
public class Address {
    private String cityName;
    private String stateName;
    private String districtName;

}
