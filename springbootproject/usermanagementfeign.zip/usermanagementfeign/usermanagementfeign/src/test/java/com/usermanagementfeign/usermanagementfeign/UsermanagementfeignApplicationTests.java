package com.usermanagementfeign.usermanagementfeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermanagementfeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
